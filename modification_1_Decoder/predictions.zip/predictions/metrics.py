from sklearn.metrics import accuracy_score, recall_score, precision_score, roc_auc_score, f1_score, confusion_matrix, roc_curve, precision_recall_curve
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import seaborn as sns
import json

def main():

    csv_file_path = "/data/data/arrv/compbio/data/BAP/epi_split/test.csv"
    df = pd.read_csv(csv_file_path)

    ground = df['p'].tolist()

    accs, recalls, precisions, aucs, f1s = [], [], [], [], []

    for i in range(5):
        with open(f"/data/data/arrv/compbio/predictions/epi/model{i+1}.json", 'r') as f:
            predictions = json.load(f)
        
        threshold = 0
        predictions = [1 if p > threshold else 0 for p in predictions]

        accs.append(accuracy_score(ground, predictions))
        recalls.append(recall_score(ground, predictions))
        precisions.append(precision_score(ground, predictions))
        aucs.append(roc_auc_score(ground, predictions))
        f1s.append(f1_score(ground, predictions))

    print(f"Accuracy: {np.mean(accs):.4f} ± {np.std(accs):.4f}")
    print(f"Recall: {np.mean(recalls):.4f} ± {np.std(recalls):.4f}")
    print(f"Precision: {np.mean(precisions):.4f} ± {np.std(precisions):.4f}")
    print(f"AUC: {np.mean(aucs):.4f} ± {np.std(aucs):.4f}")
    print(f"F1 Score: {np.mean(f1s):.4f} ± {np.std(f1s):.4f}")

if __name__ == "__main__":
    main()