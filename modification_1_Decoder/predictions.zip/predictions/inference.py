from transformers import AutoTokenizer, AutoModelForSequenceClassification
from peft import PeftModel
import torch
import pandas as pd
from sklearn.metrics import accuracy_score, recall_score, precision_score, roc_auc_score, f1_score
import numpy as np
from tqdm import tqdm
import ipdb
import json

def main():

    # Load the CSV file
    csv_file_path = "/data/data/arrv/compbio/data/BAP/epi_split/test.csv"
    df = pd.read_csv(csv_file_path)

    # Extract the prompts from the CSV file

    tokenizer = AutoTokenizer.from_pretrained(
        "nferruz/ProtGPT2"
    )
    tokenizer.pad_token = tokenizer.eos_token

# Load the base model
    model = AutoModelForSequenceClassification.from_pretrained(
        "/data/data/arrv/compbio/models/epi_model5",
        num_labels=1,
        device_map="auto",
    )

    model.config.pad_token_id = tokenizer.pad_token_id

    # Load the PEFT adapter
    # model = PeftModel.from_pretrained(base_model, "/data/data/arrv/compbio/models/reward_model_test")
    predictions = []

    batch_size = 64
    prompts = [f"{row['x1']},{row['x2']}" for _, row in df.iterrows()]
    inputs = tokenizer(prompts, return_tensors="pt", padding=True, truncation=True)

    for i in tqdm(range(0, len(prompts), batch_size)):
        batch_inputs = {k: v[i:i + batch_size] for k, v in inputs.items()}

        batch_inputs = {k: v.to('cuda') for k, v in batch_inputs.items()}

        with torch.no_grad():
            outputs = model(**batch_inputs)

        predictions.extend(outputs.logits[:, 0].tolist())

        # ipdb.set_trace()
        

    ground = df['p'].tolist()

    # Save predictions as a JSON file
    output_file_path = "/data/data/arrv/compbio/predictions/epi/model5.json"
    with open(output_file_path, 'w') as f:
        json.dump(predictions, f)

if __name__ == "__main__":
    main()