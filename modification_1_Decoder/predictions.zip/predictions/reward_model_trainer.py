from transformers import AutoTokenizer
from datasets import load_dataset
from transformers import AutoModelForSequenceClassification, BitsAndBytesConfig
from transformers import TrainingArguments
from peft import LoraConfig
from trl import RewardTrainer, RewardConfig

import os
os.environ["WANDB_API_KEY"] = "6d7a1fcf59ddcce1ac9c71fe83b670bb1e160bd9"


import json
import os
import wandb

def custom_save_model(self, output_dir):
    # Save the model
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    self.model.save_pretrained(output_dir)

    # Save tokenizer
    self.tokenizer.save_pretrained(output_dir)

    # Save args in JSON
    training_args_path = os.path.join(output_dir, "training_args.json")
    with open(training_args_path, "w") as f:
        json.dump(self.args.to_dict(), f, indent=2)


def preprocess_function(examples, tokenizer):
    new_examples = {
        "input_ids_chosen": [],
        "attention_mask_chosen": [],
        "input_ids_rejected": [],
        "attention_mask_rejected": [],
    }
    for chosen, rejected in zip(examples["chosen"], examples["rejected"]):
        tokenized_j = tokenizer(chosen, truncation=True)
        tokenized_k = tokenizer(rejected, truncation=True)

        new_examples["input_ids_chosen"].append(tokenized_j["input_ids"])
        new_examples["attention_mask_chosen"].append(tokenized_j["attention_mask"])
        new_examples["input_ids_rejected"].append(tokenized_k["input_ids"])
        new_examples["attention_mask_rejected"].append(tokenized_k["attention_mask"])

    return new_examples

def main():

    tokenizer = AutoTokenizer.from_pretrained(
        "nferruz/ProtGPT2"
    )

    # tokenizer.add_special_tokens({'pad_token': '[PAD]'})
    tokenizer.pad_token = tokenizer.eos_token

    quantization_config = BitsAndBytesConfig(
        load_in_8bit=False,
        load_in_4bit=True
    )


    model = AutoModelForSequenceClassification.from_pretrained(
        "nferruz/ProtGPT2",
        quantization_config=quantization_config,
        device_map="auto",
        trust_remote_code=True,
        num_labels=1,
    )
    model.config.use_cache = False

    model.config.pad_token_id = tokenizer.pad_token_id

    train_dataset = load_dataset("json", data_files="/data/data/arrv/compbio/data/pref_data/tcr_pref.json", split="train")

    train_dataset = train_dataset.shuffle(seed=91)#43, 69, 11, 169, 91

    train_dataset = train_dataset.map(
            lambda examples: preprocess_function(examples, tokenizer),
            batched=True,
            num_proc=4,
        )
    train_dataset = train_dataset.filter(
            lambda x: len(x["input_ids_chosen"]) <= 512
            and len(x["input_ids_rejected"]) <= 512
        )
    
    wandb.init(
        project="CompBio_RewardModel",
        name="TCR_Model",
        # api_key="6d7a1fcf59ddcce1ac9c71fe83b670bb1e160bd9",
    )

    training_args = RewardConfig(
        output_dir="/data/data/arrv/compbio/models/tcr_model5",
        center_rewards_coefficient=0.01, 
        num_train_epochs=1,
        per_device_train_batch_size=64,  
        gradient_accumulation_steps=1,  
        learning_rate=1.41e-5, 
        optim="adamw_torch", 
        report_to="wandb",
        # save_steps=50,
    )

    peft_config = LoraConfig(
        r=16,
        lora_alpha=16,
        bias="none",
        task_type="SEQ_CLS",
        modules_to_save=["scores"]
    )

    trainer = RewardTrainer(
        model=model,
        tokenizer=tokenizer,
        args=training_args,
        train_dataset=train_dataset,
        peft_config=peft_config,
        max_length=512,
    )

    trainer.train()
    output_dir = "/data/data/arrv/compbio/models/tcr_model5"
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    trainer.model.save_pretrained(output_dir)

if __name__ == "__main__":
    main()